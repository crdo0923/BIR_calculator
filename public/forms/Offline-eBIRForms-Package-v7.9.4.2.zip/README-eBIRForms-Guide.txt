========================================================================
   OFFLINE eBIRFORMS PACKAGE v7.9.4.2 & OFFICIAL TAX FORMS BUNDLE
   Bureau of Internal Revenue (BIR) — Republic of the Philippines
   Provided by BIR Co-Pilot PH • Built by DEVjules
========================================================================

ABOUT THIS PACKAGE:
This offline package contains official printable and fillable BIR Tax Forms
and installation guidance for the eBIRForms software for Filipino Freelancers,
Sole Proprietors, Mixed Income Earners, and Full-Time Employees.

INCLUDED OFFICIAL TAX FORMS (PDF):
1. BIR-Form-1701A.pdf  - Annual Income Tax Return (Pure Business/8%/OSD)
2. BIR-Form-1701Q.pdf  - Quarterly Income Tax Return for Individuals
3. BIR-Form-1701.pdf   - Annual Income Tax Return (Mixed Income Earners)
4. BIR-Form-2551Q.pdf  - Quarterly Percentage Tax Return (3% Sec 116)
5. BIR-Form-2307.pdf   - Certificate of Creditable Tax Withheld at Source (CWT)
6. BIR-Form-2316.pdf   - Certificate of Compensation Payment / Tax Withheld
7. BIR-Form-1901.pdf   - Application for Registration (Self-Employed / Freelance)

WINDOWS eBIRFORMS INSTALLATION INSTRUCTIONS:
1. System Requirements:
   - OS: Windows 7, 8, 10, or 11 (64-bit or 32-bit)
   - Minimum RAM: 2 GB
   - Disk Space: 500 MB free space
   - Runtime: Microsoft Access Database Engine & Java JRE (if prompted)

2. Step-by-Step Setup:
   Step 1: Extract all files from this archive to a local folder (e.g. C:\eBIRForms).
   Step 2: If installing the BIR eBIRForms Windows application, download the official
           installer from the official BIR Portal:
           https://www.bir.gov.ph/index.php/ebirforms.html
   Step 3: Right-click the installer and select 'Run as administrator'.
   Step 4: Follow the default setup prompts (Destination: C:\eBIRForms).
   Step 5: Launch eBIRForms from your Desktop shortcut or C:\eBIRForms\eBIRForms.exe.

3. Filing & Matching with BIR Co-Pilot:
   - Use BIR Co-Pilot (https://bir-copilot.ph) to calculate your optimal regime (8% vs Graduated).
   - Enter your Gross Receipts into Item 15.
   - For 8% Flat Tax: Item 16 is automatically ₱250,000 allowable reduction.
   - For Form 2307 Credits: Enter client withholding taxes into Item 19.
   - Validate and click 'Submit / Final Copy' to file electronically.

EASE OF PAYING TAXES (EOPT ACT - RA 11976):
Under the EOPT Act, you can pay tax returns anywhere:
- Online: Maya, GCash, LandBank Link.BizPortal, DBP PayTax, UnionBank
- Over-The-Counter: ANY Authorized Agent Bank (AAB) or Revenue District Office (RDO) nationwide.

Created and Maintained with ❤️ by DEVjules
Open-Source Philippine Tax & Payslip Suite
